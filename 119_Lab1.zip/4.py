n = int(input("enter the number : "))
sum = 0
for i in range( 1,n+1):
    sum = sum+i**2
print("Total sum od square : ",sum)